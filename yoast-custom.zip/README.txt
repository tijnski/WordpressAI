=== Yoast Custom ===
Contributors: Tijn Hoorneman
Donate link: https://tijnhoorneman.com/donate
Tags: yoast, seo, keyphrase, rest api
Yoast SEO version: 21.2
Requires at least: 4.0
Tested up to: 5.8
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A custom plugin to update Yoast SEO focus keyphrase via REST API.

== Description ==

Yoast Custom is a plugin that provides a REST API endpoint to update the Yoast SEO focus keyphrase for a given blog post.

== Installation ==

1. Upload `yoast-custom` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Usage ==

1. Make a POST request to `/wp-json/custom-yoast/v1/update-keyphrase/{POST_ID}` replacing `{POST_ID}` with the ID of the post you wish to update.
2. Include a `keyphrase` parameter in the request body to specify the new focus keyphrase. Here is an example using Python:

```python
import requests
import base64

def add_focus_keyphrase(post_id, keyphrase):
    print(f"Adding Focus Keyphrase: {keyphrase} to post ID: {post_id}...")

    # Replace with your own credentials
    username = "YourUsername"
    app_password = "YourAppPassword"
    credentials = base64.b64encode(f"{username}:{app_password}".encode()).decode()

    headers = {"Authorization": f"Basic {credentials}"}
    url = f"https://yourwebsite.com/wp-json/custom-yoast/v1/update-keyphrase/{post_id}"
    response = requests.post(url, headers=headers, json={"keyphrase": keyphrase})

    if response.status_code == 200:
        print("Keyphrase updated successfully.")
    else:
        print(f"Failed to update keyphrase: {response.text}")

# Usage example
add_focus_keyphrase(123, "New Focus Keyphrase")
Replace YourUsername, YourAppPassword, and https://yourwebsite.com with your actual WordPress username, application password, and website URL respectively. This script will send a POST request to the custom REST API endpoint created by the Yoast Custom plugin, updating the focus keyphrase of the specified blog post.

== Frequently Asked Questions ==

= How do I find the post ID? =

The post ID can be found in the URL when editing a post, or by using a plugin that displays post IDs.

== Changelog ==

= 1.0 =

Initial release.
== Upgrade Notice ==

= 1.0 =

Initial release.
