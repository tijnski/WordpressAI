<?php
/**
 * Plugin Name: Yoast Custom
 * Plugin URI: https://tijnhoorneman.com
 * Description: Custom plugin to update Yoast SEO focus keyphrase via REST API.
 * Version: 1.0
 * Author: Tijn Hoorneman
 * Author URI: https://tijnhoorneman.com
 */


// Register REST API endpoint
add_action('rest_api_init', function () {
    register_rest_route('custom-yoast/v1', '/update-keyphrase/(?P<id>\d+)', array(
        'methods' => 'POST',
        'callback' => 'update_yoast_keyphrase',
        'args' => array(
            'keyphrase' => array(
                'required' => true,
            ),
        ),
    ));
});

// Function to update Yoast SEO focus keyphrase
function update_yoast_keyphrase($data) {
    $post_id = $data['id'];
    $keyphrase = $data['keyphrase'];

    // Update Yoast SEO focus keyphrase
    $updated = update_post_meta($post_id, '_yoast_wpseo_focuskw', $keyphrase);

    if ($updated) {
        return new WP_REST_Response('Keyphrase updated successfully.', 200);
    } else {
        return new WP_Error('failed_to_update', 'Failed to update keyphrase.', array('status' => 500));
    }
}
?>